package com.imperialreader.data.source

import kotlinx.coroutines.CancellationException
import org.json.JSONArray
import org.json.JSONObject
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.io.IOException
import java.net.URI

/*
 * Anime sources (Aniyomi-style mapping onto the existing manga contract):
 *
 *   Aniyomi AnimeHttpSource            ->  this app
 *   ---------------------------------      ---------------------------------------------
 *   SAnime                             ->  SManga      (a "title" = one anime)
 *   SEpisode                           ->  SChapter    (a "chapter" = one episode)
 *   popularAnimeRequest/Parse          ->  getPopular()
 *   latestUpdatesRequest/Parse         ->  getLatest()
 *   searchAnimeRequest/Parse           ->  search()
 *   animeDetailsParse                  ->  getMangaDetails()
 *   episodeListParse                   ->  getChapters()   (newest first, like every other source here)
 *   videoListParse (+ Video.headers)   ->  loadEpisode()   (one playable URL + its headers, played by the reader's video page)
 *
 * The reader already plays a single MP4 "page"; PageAdapter was extended to also accept .m3u8 (HLS).
 * Nothing else in the reader/database/library code is aware of anime: it is just a source with isAnime = true.
 */

/** Dean Edwards p.a.c.k.e.r unpacker: many embed players hide their stream URL inside one of these. */
internal object PackedJs {
    private const val ALPHABET = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    private val packed = Regex("""\}\('((?:[^'\\]|\\.)*)',\s*(\d+),\s*(\d+),\s*'((?:[^'\\]|\\.)*)'\.split\('\|'\)""")
    private val token = Regex("""\b\w+\b""")

    private fun decode(value: String, radix: Int): Int? {
        var n = 0
        for (ch in value) {
            val digit = ALPHABET.indexOf(ch)
            if (digit < 0 || digit >= radix) return null
            n = n * radix + digit
        }
        return n
    }

    fun unpackAll(js: String): List<String> = packed.findAll(js).mapNotNull { m ->
        val payload = m.groupValues[1].replace("\\'", "'").replace("\\\\", "\\")
        val radix = m.groupValues[2].toIntOrNull()?.takeIf { it in 2..62 } ?: return@mapNotNull null
        val words = m.groupValues[4].split("|")
        token.replace(payload) { t ->
            val index = decode(t.value, radix)
            words.getOrNull(index ?: -1)?.takeIf { it.isNotEmpty() } ?: t.value
        }
    }.toList()
}

private val STREAM_REGEX =
    Regex("""https?://[^\s"'<>\\)]+?\.(?:m3u8|mp4)(?:\?[^\s"'<>\\)]*)?""", RegexOption.IGNORE_CASE)
private val EMBED_REGEX =
    Regex("""https?://[^\s"'<>\\]+/(?:v|e|embed|player)/[A-Za-z0-9_\-]{6,}[^\s"'<>\\]*""", RegexOption.IGNORE_CASE)

internal fun findStreamUrl(text: String): String? {
    val cleaned = text.replace("\\/", "/").replace("&amp;", "&")
    val all = STREAM_REGEX.findAll(cleaned).map { it.value }.toList()
    return all.firstOrNull { it.contains(".m3u8", ignoreCase = true) } ?: all.firstOrNull()
}

private fun formatNumber(n: Float): String = if (n % 1f == 0f) n.toInt().toString() else n.toString()

abstract class AnimeHttpSource : HttpSource() {
    override val lang: String get() = "en"
    override val isAnime: Boolean get() = true

    /** Implemented per site: return the playable URL of one episode plus the headers the player must send. */
    protected abstract suspend fun loadEpisode(episode: SChapter): ChapterPages

    override suspend fun getPages(chapter: SChapter): List<String> = loadEpisode(chapter).urls

    /**
     * SUB / DUB servers listed on the episode page (buttons carrying an embed URL in a data-* attribute).
     * UNVERIFIED against the live markup: when no such buttons are found only the page's default player is offered.
     */
    override suspend fun getVideoOptions(chapter: SChapter): List<VideoOption> {
        val doc = Jsoup.parse(getString(chapter.url, mapOf("Referer" to "$baseUrl/")), chapter.url)
        val found = parseServers(doc, chapter.url)
        val options = found.map { s -> VideoOption(s.label, s.dub) { resolveEmbed(s.url, chapter.url) } }
        val default = VideoOption("Default", false) { loadEpisode(chapter) }
        return if (options.any { !it.dub }) options else listOf(default) + options
    }

    private class ServerLink(val label: String, val dub: Boolean, val url: String)

    private fun parseServers(doc: Document, pageUrl: String): List<ServerLink> {
        val urlAttrs = listOf("data-embed", "data-link", "data-video", "data-url", "data-src", "data-server")
        val skipTags = setOf("img", "iframe", "script", "source", "video", "link", "meta")
        val out = LinkedHashMap<String, ServerLink>()
        for (el in doc.select(urlAttrs.joinToString(",") { "[$it]" })) {
            if (el.tagName() in skipTags || navigationChrome(el)) continue
            val raw = urlAttrs.map { el.attr(it).trim() }
                .firstOrNull { it.startsWith("http") || it.startsWith("//") || it.startsWith("/") } ?: continue
            val url = runCatching { URI(pageUrl).resolve(raw).toString() }.getOrNull() ?: continue
            if (url in out) continue
            val signals = buildString {
                append(el.text()).append(' ')
                el.attributes().forEach { append(it.value).append(' ') }
                el.parent()?.let { p ->
                    append(p.ownText()).append(' ')
                    p.attributes().forEach { append(it.value).append(' ') }
                    p.previousElementSibling()?.text()?.takeIf { it.length <= 20 }?.let { append(it) }
                }
            }.lowercase()
            val dub = "dub" in signals
            val text = el.text().trim().ifBlank { "Server ${out.size + 1}" }
            out[url] = ServerLink((if (dub) "DUB " else "SUB ") + text, dub, url)
        }
        return out.values.toList()
    }

    override suspend fun loadPages(manga: SManga, chapter: SChapter): ChapterPages = loadEpisode(chapter)

    protected fun originOf(url: String): String =
        runCatching { URI(url).let { "${it.scheme}://${it.authority}" } }.getOrDefault(baseUrl)

    /**
     * Opens an episode/embed page and looks for a direct stream: plain HTML first, then unpacked scripts, then
     * nested iframes / data-* embed links (up to two levels, each sent with the previous page as Referer).
     */
    protected suspend fun resolveEmbed(pageUrl: String, referer: String, depth: Int = 0): ChapterPages {
        val html = getString(pageUrl, mapOf("Referer" to referer))
        val texts = listOf(html) + PackedJs.unpackAll(html)
        for (text in texts) {
            val stream = findStreamUrl(text) ?: continue
            val origin = originOf(pageUrl)
            return ChapterPages(listOf(stream), mapOf("Referer" to "$origin/", "Origin" to origin))
        }
        if (depth < 2) {
            val doc = Jsoup.parse(html, pageUrl)
            val next = LinkedHashSet<String>()
            doc.select("iframe[src], iframe[data-src]").forEach {
                next += it.absUrl("src").ifBlank { it.absUrl("data-src") }
            }
            doc.select("[data-embed], [data-video], [data-url], [data-link]").forEach { el ->
                listOf("data-embed", "data-video", "data-url", "data-link")
                    .map { el.absUrl(it) }.filter { it.startsWith("http") }.forEach { next += it }
            }
            EMBED_REGEX.findAll(html.replace("\\/", "/")).forEach { next += it.value }
            for (candidate in next.filter { it.startsWith("http") && it != pageUrl }) {
                try {
                    return resolveEmbed(candidate, pageUrl, depth + 1)
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Exception) {
                    // try the next embed
                }
            }
        }
        throw IOException(
            "${name}: no playable stream found on ${originOf(pageUrl)}. " +
                "The site may use an encrypted player; check it with \"Open in WebView\"."
        )
    }

    /** Search endpoints differ between clones of the same theme, so try the usual query parameter names. */
    protected suspend fun searchWithFallbacks(
        path: String,
        query: String,
        page: Int,
        parse: (String, Int) -> MangasPage
    ): MangasPage {
        val q = query.trim()
        if (q.isEmpty()) return MangasPage(emptyList(), false)
        var last: MangasPage = MangasPage(emptyList(), false)
        for (key in listOf("keyword", "q", "s")) {
            val html = try {
                getString("$baseUrl$path?$key=${enc(q)}&page=$page")
            } catch (e: HttpStatusException) {
                if (e.code == 404) continue else throw e
            }
            val result = parse(html, page)
            if (result.mangas.isNotEmpty()) return result
            last = result
        }
        return last
    }

    // ---- shared card helpers
    protected fun cardBox(a: Element): Element =
        a.takeIf { it.selectFirst("img") != null }
            ?: a.parents().firstOrNull { it.selectFirst("img") != null && it.select("a[href]").size <= 4 }
            ?: a

    protected fun cardTitle(a: Element, box: Element): String =
        listOf(
            a.attr("title"),
            box.selectFirst("img[alt]")?.attr("alt"),
            box.selectFirst(".title, .name, .film-name, h2, h3, h4, h5")?.text(),
            a.text()
        ).map { it?.trim().orEmpty().removePrefix("Poster of ").trim() }.firstOrNull { it.isNotBlank() }.orEmpty()

    protected fun hasNextPage(doc: Document, page: Int): Boolean =
        doc.select("a[rel=next], a[title=Next]").isNotEmpty() ||
            doc.select("a[href]").any {
                val h = it.attr("href")
                h.endsWith("/page/${page + 1}") || h.endsWith("/page/${page + 1}/") || h.contains("page=${page + 1}")
            }

    protected fun navigationChrome(el: Element): Boolean =
        el.parents().any { it.tagName() in setOf("nav", "header", "footer") || it.hasClass("dropdown-menu") || it.hasClass("navbar") }
}

/** https://9anime.si — /anime/<slug> pages, episodes at /watch/<slug>-episode-N, player is an iframe embed. */
class NineAnimeSource : AnimeHttpSource() {
    override val id = "nineanime_si"
    override val name = "9anime"
    override val baseUrl = "https://9anime.si"

    override suspend fun getPopular(page: Int): MangasPage = listing("$baseUrl/search?page=$page", page)

    override suspend fun getLatest(page: Int): MangasPage =
        listing(if (page <= 1) "$baseUrl/home" else "$baseUrl/page/$page", page)

    override suspend fun search(query: String, page: Int): MangasPage =
        searchWithFallbacks("/search", query, page) { html, p -> parseListing(html, p) }

    private suspend fun listing(url: String, page: Int): MangasPage {
        val html = try {
            getString(url)
        } catch (e: HttpStatusException) {
            if (e.code == 404 && page > 1) return MangasPage(emptyList(), false)
            throw e
        }
        return parseListing(html, page)
    }

    private fun parseListing(html: String, page: Int): MangasPage {
        val doc = Jsoup.parse(html, baseUrl)
        val found = LinkedHashMap<String, SManga>()
        for (a in doc.select("a[href*=/anime/], a[href*=/watch/]")) {
            if (navigationChrome(a)) continue
            val slug = SLUG.find(a.absUrl("href"))?.groupValues?.get(1)?.replace(EPISODE_SUFFIX, "") ?: continue
            val box = cardBox(a)
            val title = cardTitle(a, box)
            val url = "$baseUrl/anime/$slug"
            val thumb = lazyImage(box.selectFirst("img"))
            val existing = found[url]
            if (existing == null) {
                if (title.isNotBlank()) found[url] = SManga(url = url, title = title, thumbnailUrl = thumb)
            } else if (existing.thumbnailUrl == null && thumb != null) {
                existing.thumbnailUrl = thumb
            }
        }
        return MangasPage(found.values.toList(), found.isNotEmpty() && hasNextPage(doc, page))
    }

    override suspend fun getMangaDetails(manga: SManga): SManga {
        val doc = Jsoup.parse(getString(manga.url), manga.url)
        doc.selectFirst("h1")?.text()?.trim()?.takeIf { it.isNotBlank() }?.let { manga.title = it }
        manga.thumbnailUrl = doc.selectFirst("meta[property=og:image]")?.absUrl("content")?.takeIf { it.isNotBlank() }
            ?: manga.thumbnailUrl
        manga.description = doc.selectFirst(".synopsis, .description, #synopsis, [class*=synopsis]")?.text()?.trim()
            ?.takeIf { it.isNotBlank() } ?: manga.description
        val genres = doc.select("a[href*=search?genre=]").filterNot(::navigationChrome).map { it.text().trim() }
            .filter { it.isNotBlank() }.distinct()
        if (genres.isNotEmpty()) manga.genre = genres.joinToString(", ")
        val text = doc.text()
        Regex("""Studios?:\s*(.+?)\s+(?:Director|Producers?)""").find(text)?.groupValues?.get(1)?.trim()
            ?.takeIf { it.isNotBlank() }?.let { manga.author = it }
        Regex("""Status:\s*(\w+)""").find(text)?.groupValues?.get(1)?.let { manga.status = statusFromText(it) }
        return manga
    }

    override suspend fun getChapters(manga: SManga): List<SChapter> {
        val slug = manga.url.substringAfter("/anime/").substringBefore('/').substringBefore('?')
        val doc = Jsoup.parse(getString(manga.url), manga.url)
        val episodes = doc.select("a[href*=/watch/$slug-episode-]").mapNotNull { a ->
            val url = a.absUrl("href").substringBefore('#').substringBefore('?')
            val n = EPISODE_NUMBER.find(url)?.groupValues?.get(1)?.toFloatOrNull() ?: return@mapNotNull null
            SChapter(url = url, name = "Episode ${formatNumber(n)}", chapterNumber = n)
        }.distinctBy { it.url }.sortedByDescending { it.chapterNumber }
        if (episodes.isEmpty()) throw IOException("9anime: no episodes found for this title")
        return episodes
    }

    override suspend fun loadEpisode(episode: SChapter): ChapterPages = resolveEmbed(episode.url, "$baseUrl/")

    private companion object {
        val SLUG = Regex("""/(?:anime|watch)/([^/?#]+)""")
        val EPISODE_SUFFIX = Regex("""-episode-\d+(?:\.\d+)?$""")
        val EPISODE_NUMBER = Regex("""-episode-(\d+(?:\.\d+)?)/?$""")
    }
}

/**
 * https://animepahetv.to — /anime/<32-char id>. The episode list is NOT in the static HTML ("Episodes (0)", filled by
 * JavaScript), so getChapters() first looks for episode links in the page, then asks [EPISODE_ENDPOINTS].
 * UNVERIFIED: open an anime page in a desktop browser, DevTools > Network > Fetch/XHR, and put the real
 * request path (with {id}) first in [EPISODE_ENDPOINTS].
 */
class AnimePaheTvSource : AnimeHttpSource() {
    override val id = "animepahetv_to"
    override val name = "AnimePahe"
    override val baseUrl = "https://animepahetv.to"

    override suspend fun getPopular(page: Int): MangasPage = listing("$baseUrl/az-list/?page=$page", page)

    override suspend fun getLatest(page: Int): MangasPage = listing("$baseUrl/latest-updated?page=$page", page)

    override suspend fun search(query: String, page: Int): MangasPage =
        searchWithFallbacks("/search", query, page) { html, p -> parseListing(html, p) }

    private suspend fun listing(url: String, page: Int): MangasPage {
        val html = try {
            getString(url)
        } catch (e: HttpStatusException) {
            if (e.code == 404 && page > 1) return MangasPage(emptyList(), false)
            throw e
        }
        return parseListing(html, page)
    }

    private fun parseListing(html: String, page: Int): MangasPage {
        val doc = Jsoup.parse(html, baseUrl)
        val found = LinkedHashMap<String, SManga>()
        for (a in doc.select("a[href*=/anime/]")) {
            if (navigationChrome(a)) continue
            val id = ANIME_ID.find(a.absUrl("href"))?.groupValues?.get(1) ?: continue
            val url = "$baseUrl/anime/$id"
            val box = cardBox(a)
            val title = cardTitle(a, box)
            val thumb = lazyImage(box.selectFirst("img"))
            val existing = found[url]
            if (existing == null) {
                found[url] = SManga(url = url, title = title, thumbnailUrl = thumb)
            } else {
                if (existing.title.isBlank() && title.isNotBlank()) existing.title = title
                if (existing.thumbnailUrl == null && thumb != null) existing.thumbnailUrl = thumb
            }
        }
        val items = found.values.filter { it.title.isNotBlank() }
        return MangasPage(items, items.isNotEmpty() && hasNextPage(doc, page))
    }

    override suspend fun getMangaDetails(manga: SManga): SManga {
        val doc = Jsoup.parse(getString(manga.url), manga.url)
        doc.selectFirst("h1")?.ownText()?.trim()?.takeIf { it.isNotBlank() }?.let { manga.title = it }
        manga.thumbnailUrl = doc.selectFirst("img[alt^=Poster of]")?.absUrl("src")?.takeIf { it.isNotBlank() }
            ?: doc.selectFirst("meta[property=og:image]")?.absUrl("content")?.takeIf { it.isNotBlank() }
            ?: manga.thumbnailUrl
        doc.select("p").filterNot(::navigationChrome).map { it.text().trim() }.maxByOrNull { it.length }
            ?.takeIf { it.length > 60 }?.let { manga.description = it }
        val genres = doc.select("a[href*=/genre/]").filterNot(::navigationChrome).map { it.text().trim() }
            .filter { it.isNotBlank() }.distinct()
        if (genres.isNotEmpty()) manga.genre = genres.joinToString(", ")
        doc.selectFirst("a[href*=/studio/]")?.text()?.trim()?.takeIf { it.isNotBlank() && !it.equals("unknown", true) }
            ?.let { manga.author = it }
        val statusText = Regex("""Status:\s*(Finished Airing|Currently Airing|Not yet aired)""", RegexOption.IGNORE_CASE)
            .find(doc.text())?.groupValues?.get(1).orEmpty().lowercase()
        manga.status = when {
            "currently" in statusText -> 1
            "finished" in statusText -> 2
            else -> manga.status
        }
        return manga
    }

    override suspend fun getChapters(manga: SManga): List<SChapter> {
        val animeId = ANIME_ID.find(manga.url)?.groupValues?.get(1) ?: throw IOException("AnimePahe: bad title URL")
        val fromPage = parseEpisodeLinks(Jsoup.parse(getString(manga.url), manga.url), animeId)
        if (fromPage.isNotEmpty()) return fromPage
        var lastError: Exception? = null
        for (template in EPISODE_ENDPOINTS) {
            try {
                val episodes = parseEpisodeResponse(getString(template.replace("{id}", animeId)), animeId)
                if (episodes.isNotEmpty()) return episodes
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                lastError = e
            }
        }
        throw IOException(
            "AnimePahe: the episode list is loaded by the site's JavaScript and no known endpoint answered " +
                "(set the real one in EPISODE_ENDPOINTS)." + (lastError?.message?.let { " Last error: $it" } ?: "")
        )
    }

    private fun parseEpisodeLinks(doc: Document, animeId: String): List<SChapter> =
        doc.select("a[href*=/watch/], a[href*=/episode/], a[data-episode], a[data-id]").mapNotNull { a ->
            val url = a.absUrl("href").substringBefore('#')
            if (!url.startsWith("http") || url.contains("/anime/")) return@mapNotNull null
            episodeOf(url, a.text(), a.attr("data-episode"))
        }.distinctBy { it.url }.sortedByDescending { it.chapterNumber }

    private fun episodeOf(url: String, label: String, hint: String = ""): SChapter? {
        val n = listOf(hint, label, url).mapNotNull { Regex("""(\d+(?:\.\d+)?)(?!.*\d)""").find(it)?.groupValues?.get(1)?.toFloatOrNull() }
            .firstOrNull() ?: return null
        return SChapter(url = url, name = "Episode ${formatNumber(n)}", chapterNumber = n)
    }

    private fun parseEpisodeResponse(body: String, animeId: String): List<SChapter> {
        val trimmed = body.trim()
        val html = when {
            trimmed.startsWith("{") -> JSONObject(trimmed).optString("html").ifBlank { trimmed }
            trimmed.startsWith("[") -> {
                val array = JSONArray(trimmed)
                return (0 until array.length()).mapNotNull { i ->
                    val o = array.optJSONObject(i) ?: return@mapNotNull null
                    val ref = listOf("url", "link", "session", "slug", "id").map { o.optString(it) }.firstOrNull { it.isNotBlank() }
                        ?: return@mapNotNull null
                    val url = if (ref.startsWith("http")) ref else "$baseUrl/watch/$animeId/$ref"
                    val label = listOf("title", "name", "episode", "number").map { o.optString(it) }.firstOrNull { it.isNotBlank() }.orEmpty()
                    episodeOf(url, label, o.optString("episode"))
                }.distinctBy { it.url }.sortedByDescending { it.chapterNumber }
            }
            else -> trimmed
        }
        return parseEpisodeLinks(Jsoup.parse(html, baseUrl), animeId)
    }

    override suspend fun loadEpisode(episode: SChapter): ChapterPages = resolveEmbed(episode.url, "$baseUrl/")

    private companion object {
        val ANIME_ID = Regex("""/anime/([0-9a-fA-F]{32})""")

        /** UNVERIFIED guesses (common for this kind of site). Replace with the request seen in the browser's Network tab. */
        val EPISODE_ENDPOINTS = listOf(
            "https://animepahetv.to/ajax/episode/list/{id}",
            "https://animepahetv.to/ajax/episodes/{id}",
            "https://animepahetv.to/api/episodes/{id}"
        )
    }
}
