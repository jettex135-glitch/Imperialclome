package com.imperialreader.ui.theme

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.card.MaterialCardView
import com.imperialreader.util.dp
import com.imperialreader.util.toast

class ThemeEditorActivity : AppCompatActivity() {
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val active = AppThemeManager.current(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(24))
            setBackgroundColor(active.background)
        }

        content.addView(Button(this).apply {
            text = "‹  Back to Settings"
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
            setOnClickListener { finish() }
        })
        content.addView(TextView(this).apply {
            text = "Choose a look"
            textSize = 26f
            setTextColor(active.text)
            setPadding(0, dp(12), 0, dp(4))
        })
        content.addView(TextView(this).apply {
            text = "Tap a theme to apply it immediately. Changes also carry across app screens."
            textSize = 14f
            setTextColor(active.secondaryText)
            setPadding(0, 0, 0, dp(16))
        })

        AppThemeManager.all(this).forEach { theme ->
            val selected = theme.name == active.name
            val card = MaterialCardView(this).apply {
                radius = dp(16).toFloat()
                setCardBackgroundColor(theme.surface)
                strokeWidth = dp(if (selected) 2 else 1)
                strokeColor = if (selected) theme.primary else theme.card
                isClickable = true
                isFocusable = true
                setOnClickListener { applyTheme(theme) }
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(12) }
            }
            val body = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), dp(14), dp(16), dp(14))
            }
            val titleRow = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
            }
            titleRow.addView(TextView(this).apply {
                text = theme.name
                textSize = 17f
                setTextColor(theme.text)
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            titleRow.addView(TextView(this).apply {
                text = if (selected) "SELECTED" else "TAP TO APPLY"
                textSize = 11f
                setTextColor(theme.accent)
            })
            body.addView(titleRow)
            body.addView(TextView(this).apply {
                text = "A quick preview of your app colors"
                textSize = 13f
                setTextColor(theme.secondaryText)
                setPadding(0, dp(4), 0, dp(12))
            })
            body.addView(colorSwatches(theme))

            if (theme.name !in AppThemeManager.builtInNames()) {
                val actions = LinearLayout(this).apply {
                    gravity = Gravity.END
                    setPadding(0, dp(8), 0, 0)
                }
                actions.addView(Button(this).apply {
                    text = "Edit"
                    setOnClickListener { editTheme(theme, theme.name) }
                })
                actions.addView(Button(this).apply {
                    text = "Delete"
                    setOnClickListener { confirmDelete(theme) }
                })
                body.addView(actions)
            }
            card.addView(body)
            content.addView(card)
        }

        content.addView(Button(this).apply {
            text = "Create a custom theme"
            setOnClickListener { editTheme(AppThemeManager.current(this@ThemeEditorActivity), null) }
        })
        setContentView(ScrollView(this).apply { addView(content) })
        AppThemeManager.apply(this)
    }

    private fun colorSwatches(theme: AppColorTheme): View {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        listOf(
            "Primary" to theme.primary,
            "Accent" to theme.accent,
            "Background" to theme.background,
            "Surface" to theme.surface,
            "Card" to theme.card
        ).forEach { (label, color) ->
            row.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                addView(View(this@ThemeEditorActivity).apply {
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(color)
                        setStroke(dp(1), theme.secondaryText)
                    }
                    layoutParams = LinearLayout.LayoutParams(dp(28), dp(28)).apply {
                        bottomMargin = dp(4)
                    }
                })
                addView(TextView(this@ThemeEditorActivity).apply {
                    text = label
                    textSize = 9f
                    setTextColor(theme.secondaryText)
                })
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        return row
    }

    private fun applyTheme(theme: AppColorTheme) {
        AppThemeManager.select(this, theme.name)
        AppThemeManager.apply(this)
        render()
        toast("${theme.name} theme applied")
    }

    private fun confirmDelete(theme: AppColorTheme) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Delete ${theme.name}?")
            .setMessage("This only removes the saved custom theme. Built-in themes cannot be deleted.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ ->
                AppThemeManager.delete(this, theme.name)
                render()
            }
            .show()
    }

    private fun editTheme(initial: AppColorTheme, originalName: String?) {
        val name = EditText(this).apply {
            hint = "Theme name"
            setSingleLine()
            setText(originalName ?: "")
        }
        val fields = linkedMapOf<String, EditText>()
        val propertyRows = listOf(
            "Primary" to initial.primary,
            "Secondary" to initial.secondary,
            "Accent" to initial.accent,
            "Background" to initial.background,
            "Surface" to initial.surface,
            "Card" to initial.card,
            "Primary text" to initial.text,
            "Secondary text" to initial.secondaryText,
            "Navigation bar" to initial.navigationBar,
            "Status bar" to initial.statusBar
        )
        val form = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        form.addView(name)
        propertyRows.forEach { (label, color) ->
            val input = EditText(this).apply {
                hint = "$label color (for example #A98245)"
                setSingleLine()
                setText(String.format("#%06X", 0xFFFFFF and color))
            }
            fields[label] = input
            form.addView(input)
        }
        val preview = TextView(this).apply {
            text = "Preview · buttons and text"
            gravity = Gravity.CENTER
            textSize = 16f
            setPadding(dp(12), dp(18), dp(12), dp(18))
        }
        form.addView(preview)

        fun updatePreview() {
            val background = parseOrNull(fields, "Background") ?: initial.background
            val surface = parseOrNull(fields, "Surface") ?: initial.surface
            val primary = parseOrNull(fields, "Primary") ?: initial.primary
            val text = parseOrNull(fields, "Primary text") ?: initial.text
            preview.setBackgroundColor(surface)
            preview.setTextColor(text)
            preview.text = "Preview · sample action  ${String.format("#%06X", 0xFFFFFF and primary)}"
            form.setBackgroundColor(background)
        }
        fields.values.forEach { it.addTextChangedListener { updatePreview() } }
        updatePreview()

        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle(if (originalName == null) "Create custom theme" else "Edit ${originalName}")
            .setView(ScrollView(this).apply { addView(form) })
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                try {
                    val theme = AppColorTheme(
                        name = name.text.toString().trim(),
                        primary = parse(fields, "Primary"),
                        secondary = parse(fields, "Secondary"),
                        accent = parse(fields, "Accent"),
                        background = parse(fields, "Background"),
                        surface = parse(fields, "Surface"),
                        card = parse(fields, "Card"),
                        text = parse(fields, "Primary text"),
                        secondaryText = parse(fields, "Secondary text"),
                        navigationBar = parse(fields, "Navigation bar"),
                        statusBar = parse(fields, "Status bar")
                    )
                    require(theme.name.isNotBlank()) { "Enter a theme name" }
                    require(AppThemeManager.builtInNames().none { it.equals(theme.name, ignoreCase = true) }) {
                        "That name is reserved for a built-in theme"
                    }
                    require(AppThemeManager.isReadable(theme)) {
                        "Increase primary and secondary text contrast against the background."
                    }
                    if (originalName != null && originalName != theme.name) {
                        AppThemeManager.delete(this, originalName)
                    }
                    AppThemeManager.save(this, theme)
                    dialog.dismiss()
                    render()
                    toast("${theme.name} theme saved and applied")
                } catch (e: Exception) {
                    toast(e.message ?: "Could not save this theme")
                }
            }
        }
        dialog.show()
    }

    private fun parse(fields: Map<String, EditText>, key: String): Int =
        Color.parseColor(fields.getValue(key).text.toString().trim())

    private fun parseOrNull(fields: Map<String, EditText>, key: String): Int? =
        runCatching { parse(fields, key) }.getOrNull()
}
