package com.imperialreader.ui.theme

import android.app.Activity
import android.app.Application
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.view.WindowCompat
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.imperialreader.R
import org.json.JSONArray
import org.json.JSONObject

data class AppColorTheme(
    val name: String,
    val primary: Int,
    val secondary: Int,
    val accent: Int,
    val background: Int,
    val surface: Int,
    val card: Int,
    val text: Int,
    val secondaryText: Int,
    val navigationBar: Int,
    val statusBar: Int
)

object AppThemeManager {
    private const val PREFS = "custom_application_themes"
    private const val KEY_LIST = "themes"
    private const val KEY_ACTIVE = "active"
    private val defaultTheme = AppColorTheme(
        name = "Imperial Reader",
        primary = Color.rgb(169, 130, 69),
        secondary = Color.rgb(169, 130, 69),
        accent = Color.rgb(210, 183, 126),
        background = Color.rgb(10, 10, 10),
        surface = Color.rgb(20, 20, 20),
        card = Color.rgb(28, 28, 28),
        text = Color.rgb(232, 232, 232),
        secondaryText = Color.rgb(160, 160, 160),
        navigationBar = Color.rgb(16, 16, 16),
        statusBar = Color.rgb(10, 10, 10)
    )
    private val builtInThemes = listOf(
        defaultTheme,
        AppColorTheme(
            name = "Ocean",
            primary = Color.rgb(72, 164, 196),
            secondary = Color.rgb(72, 164, 196),
            accent = Color.rgb(139, 211, 226),
            background = Color.rgb(7, 17, 26),
            surface = Color.rgb(13, 30, 43),
            card = Color.rgb(20, 43, 58),
            text = Color.rgb(235, 246, 249),
            secondaryText = Color.rgb(169, 197, 207),
            navigationBar = Color.rgb(9, 23, 33),
            statusBar = Color.rgb(7, 17, 26)
        ),
        AppColorTheme(
            name = "Forest",
            primary = Color.rgb(91, 174, 111),
            secondary = Color.rgb(91, 174, 111),
            accent = Color.rgb(157, 213, 160),
            background = Color.rgb(10, 20, 13),
            surface = Color.rgb(17, 32, 21),
            card = Color.rgb(26, 45, 30),
            text = Color.rgb(237, 247, 237),
            secondaryText = Color.rgb(174, 201, 177),
            navigationBar = Color.rgb(13, 25, 16),
            statusBar = Color.rgb(10, 20, 13)
        ),
        AppColorTheme(
            name = "Rose",
            primary = Color.rgb(211, 105, 139),
            secondary = Color.rgb(211, 105, 139),
            accent = Color.rgb(240, 158, 181),
            background = Color.rgb(25, 12, 19),
            surface = Color.rgb(39, 19, 30),
            card = Color.rgb(54, 27, 41),
            text = Color.rgb(250, 239, 244),
            secondaryText = Color.rgb(210, 178, 191),
            navigationBar = Color.rgb(31, 15, 24),
            statusBar = Color.rgb(25, 12, 19)
        )
    )

    fun all(context: Context): List<AppColorTheme> {
        val saved = runCatching {
            JSONArray(prefs(context).getString(KEY_LIST, "[]")).let { array ->
                (0 until array.length()).mapNotNull { index -> array.optJSONObject(index)?.toTheme() }
            }
        }.getOrElse { emptyList() }
        val builtInNames = builtInThemes.mapTo(HashSet()) { it.name }
        return builtInThemes + saved
            .filterNot { it.name in builtInNames }
            .distinctBy { it.name }
    }

    fun current(context: Context): AppColorTheme {
        val selected = prefs(context).getString(KEY_ACTIVE, defaultTheme.name)
        return all(context).firstOrNull { it.name == selected } ?: defaultTheme
    }

    fun builtInNames(): Set<String> = builtInThemes.mapTo(LinkedHashSet()) { it.name }

    fun select(context: Context, name: String) {
        require(all(context).any { it.name == name }) { "Unknown theme" }
        prefs(context).edit().putString(KEY_ACTIVE, name).apply()
    }

    fun save(context: Context, theme: AppColorTheme) {
        require(theme.name.isNotBlank() && builtInThemes.none { it.name.equals(theme.name, ignoreCase = true) }) {
            "Choose a name other than a built-in theme"
        }
        require(hasReadableContrast(theme)) { "Text colors need stronger contrast with the background" }
        val themes = all(context).filterNot { it.name in builtInThemes.map(AppColorTheme::name) || it.name == theme.name }
        prefs(context).edit()
            .putString(KEY_LIST, JSONArray().apply {
                (themes + theme).forEach { put(it.toJson()) }
            }.toString())
            .putString(KEY_ACTIVE, theme.name)
            .apply()
    }

    fun delete(context: Context, name: String) {
        require(builtInThemes.none { it.name == name }) { "Built-in themes cannot be deleted" }
        val themes = all(context).filterNot { it.name == name || it.name in builtInThemes.map(AppColorTheme::name) }
        prefs(context).edit()
            .putString(KEY_LIST, JSONArray().apply { themes.forEach { put(it.toJson()) } }.toString())
            .putString(KEY_ACTIVE, if (current(context).name == name) defaultTheme.name else current(context).name)
            .apply()
    }

    fun apply(activity: Activity) {
        val theme = current(activity)
        activity.window.statusBarColor = theme.statusBar
        activity.window.navigationBarColor = theme.navigationBar
        WindowCompat.getInsetsController(activity.window, activity.window.decorView).apply {
            isAppearanceLightStatusBars = isLight(theme.statusBar)
            isAppearanceLightNavigationBars = isLight(theme.navigationBar)
        }
        if (activity !is ThemeEditorActivity) {
            val decor = activity.window.decorView
            applyToView(decor, theme)
            if (decor.getTag(R.id.theme_layout_listener) == null) {
                val listener = android.view.ViewTreeObserver.OnGlobalLayoutListener {
                    if (decor.isAttachedToWindow) {
                        applyToView(decor, current(decor.context))
                    }
                }
                decor.setTag(R.id.theme_layout_listener, listener)
                decor.viewTreeObserver.addOnGlobalLayoutListener(listener)
            }
        }
    }

    fun isReadable(theme: AppColorTheme): Boolean = hasReadableContrast(theme)

    private fun applyToView(view: View, theme: AppColorTheme) {
        val originalBackground = originalColor(view, R.id.theme_original_background) {
            (view.background as? ColorDrawable)?.color ?: NO_COLOR
        }
        val mappedBackground = mappedColor(originalBackground, theme)
        val originalBackgroundTint = originalColor(view, R.id.theme_original_background_tint) {
            view.backgroundTintList?.defaultColor ?: NO_COLOR
        }
        when (view) {
            is MaterialToolbar -> {
                view.setBackgroundColor(theme.surface)
                view.setTitleTextColor(theme.text)
                view.navigationIcon?.setTint(theme.accent)
                view.overflowIcon?.setTint(theme.accent)
            }
            is MaterialCardView -> view.setCardBackgroundColor(theme.card)
            else -> if (mappedBackground != null) view.setBackgroundColor(mappedBackground)
        }
        mappedColor(originalBackgroundTint, theme)?.let {
            view.backgroundTintList = android.content.res.ColorStateList.valueOf(it)
        }
        if (view is TextView) {
            val originalText = originalColor(view, R.id.theme_original_text) { view.currentTextColor }
            mappedColor(originalText, theme)?.let(view::setTextColor)
            if (view is MaterialButton) {
                originalColor(view, R.id.theme_original_button_tint) {
                    view.backgroundTintList?.defaultColor ?: theme.primary
                }
                view.backgroundTintList = android.content.res.ColorStateList.valueOf(theme.primary)
                view.setTextColor(contentColor(theme.primary))
            }
        }
        if (view is MaterialCardView) {
            originalColor(view, R.id.theme_original_card_background) {
                (view.background as? ColorDrawable)?.color ?: NO_COLOR
            }
            view.setCardBackgroundColor(theme.card)
        }
        if (view is ImageView) {
            val originalTint = originalColor(view, R.id.theme_original_image_tint) {
                view.imageTintList?.defaultColor ?: NO_COLOR
            }
            mappedColor(originalTint, theme)?.let {
                view.imageTintList = android.content.res.ColorStateList.valueOf(it)
            }
            if (view.colorFilter != null) view.setColorFilter(theme.primary)
        }
        if (view is ProgressBar) {
            view.progressTintList = android.content.res.ColorStateList.valueOf(theme.accent)
            view.indeterminateTintList = android.content.res.ColorStateList.valueOf(theme.accent)
        }
        if (view is ViewGroup) {
            for (index in 0 until view.childCount) applyToView(view.getChildAt(index), theme)
        }
    }

    fun contentColor(background: Int): Int =
        if (contrast(Color.BLACK, background) >= contrast(Color.WHITE, background)) Color.BLACK else Color.WHITE

    private fun mappedColor(color: Int, theme: AppColorTheme): Int? = when (color) {
        Color.rgb(10, 10, 10) -> theme.background
        Color.rgb(16, 16, 16), Color.rgb(20, 20, 20) -> theme.surface
        Color.rgb(24, 24, 24), Color.rgb(28, 28, 28) -> theme.card
        Color.rgb(240, 240, 240) -> theme.surface
        Color.rgb(169, 130, 69) -> theme.primary
        Color.rgb(210, 183, 126) -> theme.accent
        Color.rgb(232, 232, 232), Color.WHITE -> theme.text
        Color.rgb(160, 160, 160) -> theme.secondaryText
        else -> {
            val alpha = Color.alpha(color)
            if (alpha in 1..254 && Color.red(color) == 0 && Color.green(color) == 0 && Color.blue(color) == 0) {
                (theme.background and 0x00FFFFFF) or (alpha shl 24)
            } else {
                null
            }
        }
    }

    private fun originalColor(view: View, key: Int, read: () -> Int): Int {
        val cached = view.getTag(key) as? Int
        if (cached != null) return cached
        return read().also { view.setTag(key, it) }
    }

    private fun isLight(color: Int): Boolean =
        (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) > 160

    private fun hasReadableContrast(theme: AppColorTheme): Boolean =
        contrast(theme.text, theme.background) >= 4.5 &&
            contrast(theme.secondaryText, theme.background) >= 3.0

    private fun contrast(first: Int, second: Int): Double {
        val a = luminance(first)
        val b = luminance(second)
        return (maxOf(a, b) + 0.05) / (minOf(a, b) + 0.05)
    }

    private fun luminance(color: Int): Double {
        fun channel(value: Int): Double {
            val normalized = value / 255.0
            return if (normalized <= 0.04045) normalized / 12.92 else Math.pow((normalized + 0.055) / 1.055, 2.4)
        }
        return 0.2126 * channel(Color.red(color)) +
            0.7152 * channel(Color.green(color)) +
            0.0722 * channel(Color.blue(color))
    }

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private const val NO_COLOR = Int.MIN_VALUE

    private fun JSONObject.toTheme(): AppColorTheme? = runCatching {
        AppColorTheme(
            name = getString("name"),
            primary = getInt("primary"),
            secondary = getInt("secondary"),
            accent = getInt("accent"),
            background = getInt("background"),
            surface = getInt("surface"),
            card = getInt("card"),
            text = getInt("text"),
            secondaryText = getInt("secondaryText"),
            navigationBar = getInt("navigationBar"),
            statusBar = getInt("statusBar")
        )
    }.getOrNull()

    private fun AppColorTheme.toJson() = JSONObject()
        .put("name", name)
        .put("primary", primary)
        .put("secondary", secondary)
        .put("accent", accent)
        .put("background", background)
        .put("surface", surface)
        .put("card", card)
        .put("text", text)
        .put("secondaryText", secondaryText)
        .put("navigationBar", navigationBar)
        .put("statusBar", statusBar)
}

class AppThemeLifecycleCallbacks : Application.ActivityLifecycleCallbacks {
    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) = Unit
    override fun onActivityStarted(activity: Activity) = Unit
    override fun onActivityResumed(activity: Activity) = AppThemeManager.apply(activity)
    override fun onActivityPaused(activity: Activity) = Unit
    override fun onActivityStopped(activity: Activity) = Unit
    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) = Unit
    override fun onActivityDestroyed(activity: Activity) = Unit
}
